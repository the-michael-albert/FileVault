package one.michaelalbert.entryservice;

import one.michaelalbert.entryservice.commons.FileObject;
import one.michaelalbert.entryservice.database.DatabaseConnector;

import java.sql.*;
import java.util.Random;

public class Main {
    public static void main(String[] args) throws ClassNotFoundException {
        DatabaseConnector connector = new DatabaseConnector();
    }


}
